#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
    public class TTMIndicator : Indicator
    {
        private int period = 6;
        private double kcMultiplier = 1.5;
        private double bbMultiplier = 3.3;
        private List<double> priceValues = new List<double>();
        private double lastRegression = 0;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Tiki Squeeze Indicator based on Bollinger Bands and Keltner Channels.";
                Name = "TTMIndicator";
                Calculate = Calculate.OnEachTick;
                AddPlot(new Stroke(Brushes.Red), PlotStyle.Dot, "SqueezeDot");
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < period) return;

            double close = Close[0];
            double high = High[0];
            double low = Low[0];
            double closeSMAValue = SMA(Close, period)[0];
            double atr = kcMultiplier * SMA(ATR(period), period)[0];
            double kcUpper = closeSMAValue + atr;
            double kcLower = closeSMAValue - atr;

            double stdev = StdDev(Close, period)[0];
            double avg = closeSMAValue;
            double halfWidth = stdev * bbMultiplier;
            double bbUpper = avg + halfWidth;
            double bbLower = avg - halfWidth;

            bool isSqueeze = bbUpper < kcUpper && bbLower > kcLower;

            double sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
            for (int i = 0; i < priceValues.Count; i++)
            {
                double x = i + 1;
                double y = priceValues[i];
                sumX += x;
                sumY += y;
                sumXY += x * y;
                sumXX += x * x;
            }

            double n = priceValues.Count;
            double slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
            double intercept = (sumY - slope * sumX) / n;
            double regression = intercept + slope * n;

            Brush dotColor;
            if (isSqueeze)
            {
                dotColor = Brushes.White;
            }
            else
            {
                if (regression > 0)
                {
                    dotColor = regression > lastRegression ? Brushes.Green : Brushes.Orange;
                }
                else
                {
                    dotColor = regression < lastRegression ? Brushes.Red : Brushes.Yellow;
                }
            }

            lastRegression = regression;

            PlotBrushes[0][0] = dotColor;
            Values[0][0] = low - 2 * TickSize;

            double highest = Double.MinValue;
            double lowest = Double.MaxValue;

            for (int i = 0; i < period; i++)
            {
                if (Highs[0][i] > highest) highest = Highs[0][i];
                if (Lows[0][i] < lowest) lowest = Lows[0][i];
            }

            double closeEMAValue = EMA(Close, period)[0];
            double value = close - ((highest + lowest) / 2 + closeEMAValue) / 2;

            if (priceValues.Count >= period)
            {
                priceValues.RemoveAt(0);
            }
            priceValues.Add(value);
        }
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private TTMIndicator[] cacheTTMIndicator;
		public TTMIndicator TTMIndicator()
		{
			return TTMIndicator(Input);
		}

		public TTMIndicator TTMIndicator(ISeries<double> input)
		{
			if (cacheTTMIndicator != null)
				for (int idx = 0; idx < cacheTTMIndicator.Length; idx++)
					if (cacheTTMIndicator[idx] != null &&  cacheTTMIndicator[idx].EqualsInput(input))
						return cacheTTMIndicator[idx];
			return CacheIndicator<TTMIndicator>(new TTMIndicator(), input, ref cacheTTMIndicator);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.TTMIndicator TTMIndicator()
		{
			return indicator.TTMIndicator(Input);
		}

		public Indicators.TTMIndicator TTMIndicator(ISeries<double> input )
		{
			return indicator.TTMIndicator(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.TTMIndicator TTMIndicator()
		{
			return indicator.TTMIndicator(Input);
		}

		public Indicators.TTMIndicator TTMIndicator(ISeries<double> input )
		{
			return indicator.TTMIndicator(input);
		}
	}
}

#endregion
